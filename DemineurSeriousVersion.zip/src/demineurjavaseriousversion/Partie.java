/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demineurjavaseriousversion;

/**
 *
 * @authors
 * Didi Orlog SOSSOU
 * Edo Amen YAWOVI
 * Essowaza Samuel ATAKE
 */
public class Partie {
    int seconde;
    long tempDebut = System.currentTimeMillis();
    int tempsPartie;
    
    
    public Partie(int tempsPartie){
        this.tempsPartie=tempsPartie;
    }

    public int getSeconde() {
        return seconde;
    }

    public void setSeconde(int seconde) {
        this.seconde = seconde;
    }

    public int getTempsPartie() {
        return tempsPartie;
    }

    public void setTempsPartie(int tempsPartie) {
        this.tempsPartie = tempsPartie;
    }
    
    
    public int count() throws InterruptedException{
        for(int i=0; i<getTempsPartie(); i++){
            this.setSeconde(i);
            Thread.sleep(1000);
            System.out.println(this.getSeconde());
        }
        
        return this.getSeconde();
    }
    
    
}
