/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demineurjavaseriousversion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samuel
 */
public class DatabaseConnexion {
    //Connexion à la base de données
    Connection c = null;
    Statement stmt = null;
    ResultSet rs = null;
    String url = "jdbc:mysql://localhost:3306/demineur";
    String user = "root";
    String password = "";
    
    
    public Connection connexion(){
        try {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DatabaseConnexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            c = DriverManager.getConnection(url, user, password);
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseConnexion.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        if(c != null){
            System.out.println("Vous êtes connecté!");
        }else{
            System.out.println("Connexion échouée!");
        }
    }catch(Exception e ) {
        System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        //JOptionPane.showMessageDialog(null, "La connexion a échoué!");
     }
    
    
    return c;
    
}
}
